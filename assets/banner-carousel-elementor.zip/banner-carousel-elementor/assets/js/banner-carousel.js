(function () {
	'use strict';

	function initCarousel( carouselEl ) {
		var slides = carouselEl.querySelectorAll( '.bce-slide' );
		if ( ! slides.length ) {
			return;
		}

		var dotsWrap    = carouselEl.querySelector( '.bce-dots' );
		var dots        = dotsWrap ? dotsWrap.querySelectorAll( 'button' ) : [];
		var prevBtn     = carouselEl.querySelector( '.bce-arrow-prev' );
		var nextBtn     = carouselEl.querySelector( '.bce-arrow-next' );

		var autoplay       = carouselEl.getAttribute( 'data-autoplay' ) === 'true';
		var autoplaySpeed  = parseInt( carouselEl.getAttribute( 'data-autoplay-speed' ), 10 ) || 4000;
		var transitionTime = parseInt( carouselEl.getAttribute( 'data-transition-speed' ), 10 ) || 600;
		var pauseOnHover   = carouselEl.getAttribute( 'data-pause-on-hover' ) === 'true';

		var current  = 0;
		var timer    = null;

		// Apply transition speed dynamically.
		slides.forEach( function ( slide ) {
			slide.style.transitionDuration = transitionTime + 'ms';
		} );

		function goTo( index ) {
			if ( index === current ) {
				return;
			}
			slides[ current ].classList.remove( 'active' );
			if ( dots[ current ] ) {
				dots[ current ].classList.remove( 'active' );
			}

			current = ( index + slides.length ) % slides.length;

			slides[ current ].classList.add( 'active' );
			if ( dots[ current ] ) {
				dots[ current ].classList.add( 'active' );
			}
		}

		function next() {
			goTo( current + 1 );
		}

		function prev() {
			goTo( current - 1 );
		}

		function startAutoplay() {
			if ( ! autoplay || slides.length < 2 ) {
				return;
			}
			stopAutoplay();
			timer = setInterval( next, autoplaySpeed );
		}

		function stopAutoplay() {
			if ( timer ) {
				clearInterval( timer );
				timer = null;
			}
		}

		// Initial state.
		slides[ 0 ].classList.add( 'active' );

		// Dot clicks.
		dots.forEach( function ( dot ) {
			dot.addEventListener( 'click', function () {
				var idx = parseInt( dot.getAttribute( 'data-slide-index' ), 10 );
				goTo( idx );
				startAutoplay();
			} );
		} );

		// Arrow clicks.
		if ( nextBtn ) {
			nextBtn.addEventListener( 'click', function () {
				next();
				startAutoplay();
			} );
		}
		if ( prevBtn ) {
			prevBtn.addEventListener( 'click', function () {
				prev();
				startAutoplay();
			} );
		}

		// Pause on hover.
		if ( pauseOnHover ) {
			carouselEl.addEventListener( 'mouseenter', stopAutoplay );
			carouselEl.addEventListener( 'mouseleave', startAutoplay );
		}

		// Basic touch swipe support.
		var touchStartX = 0;
		carouselEl.addEventListener( 'touchstart', function ( e ) {
			touchStartX = e.changedTouches[ 0 ].screenX;
		}, { passive: true } );

		carouselEl.addEventListener( 'touchend', function ( e ) {
			var touchEndX = e.changedTouches[ 0 ].screenX;
			var diff = touchEndX - touchStartX;
			if ( Math.abs( diff ) > 40 ) {
				if ( diff < 0 ) {
					next();
				} else {
					prev();
				}
				startAutoplay();
			}
		}, { passive: true } );

		startAutoplay();
	}

	function initAll() {
		var carousels = document.querySelectorAll( '.bce-carousel' );
		carousels.forEach( initCarousel );
	}

	// Normal front-end load.
	document.addEventListener( 'DOMContentLoaded', initAll );

	// Re-init inside the Elementor editor when the widget is rendered/updated.
	if ( window.elementorFrontend ) {
		window.addEventListener( 'elementor/frontend/init', function () {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/banner_image_carousel.default', function ( $scope ) {
				var el = $scope[ 0 ] ? $scope[ 0 ].querySelector( '.bce-carousel' ) : null;
				if ( el ) {
					initCarousel( el );
				}
			} );
		} );
	}
})();
