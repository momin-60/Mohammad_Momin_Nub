<?php
/**
 * Plugin Name: Banner Image Carousel for Elementor
 * Description: Ekta custom Elementor widget jeta diye apni banner image carousel banate parben. Height 700px, width 100%, image upload + link option, cover/contain fit, ar niche navigation dots thakbe.
 * Plugin URI: https://example.com
 * Version: 1.0.0
 * Author: Custom Build
 * Text Domain: banner-carousel-elementor
 * Elementor tested up to: 3.25
 * Elementor Pro tested up to: 3.25
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access disallowed.
}

define( 'BCE_VERSION', '1.0.0' );
define( 'BCE_PLUGIN_FILE', __FILE__ );
define( 'BCE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BCE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Check if Elementor is active before loading anything.
 */
function bce_check_elementor_dependency() {
	if ( ! did_action( 'elementor/loaded' ) ) {
		add_action( 'admin_notices', 'bce_admin_notice_missing_elementor' );
		return false;
	}
	return true;
}

function bce_admin_notice_missing_elementor() {
	if ( isset( $_GET['activate'] ) ) {
		unset( $_GET['activate'] );
	}

	$message = sprintf(
		esc_html__( '"%1$s" plugin ta kaj korar jonno "%2$s" plugin ta install ebong activate kora lagbe.', 'banner-carousel-elementor' ),
		'<strong>' . esc_html__( 'Banner Image Carousel for Elementor', 'banner-carousel-elementor' ) . '</strong>',
		'<strong>' . esc_html__( 'Elementor', 'banner-carousel-elementor' ) . '</strong>'
	);

	printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
}

/**
 * Register the widget with Elementor once Elementor & its widgets are ready.
 */
function bce_register_widget( $widgets_manager ) {
	require_once BCE_PLUGIN_DIR . 'includes/class-banner-carousel-widget.php';
	$widgets_manager->register( new \Banner_Carousel_Widget() );
}

/**
 * Register a custom widget category (optional, keeps things tidy).
 */
function bce_register_widget_category( $elements_manager ) {
	$elements_manager->add_category(
		'banner-carousel-category',
		array(
			'title' => esc_html__( 'Banner Carousel', 'banner-carousel-elementor' ),
			'icon'  => 'fa fa-plug',
		)
	);
}

/**
 * Enqueue front-end assets only when needed.
 */
function bce_enqueue_assets() {
	wp_register_style( 'bce-style', BCE_PLUGIN_URL . 'assets/css/banner-carousel.css', array(), BCE_VERSION );
	wp_register_script( 'bce-script', BCE_PLUGIN_URL . 'assets/js/banner-carousel.js', array(), BCE_VERSION, true );
}

add_action( 'wp_enqueue_scripts', 'bce_enqueue_assets' );

add_action( 'plugins_loaded', function () {
	if ( bce_check_elementor_dependency() ) {
		add_action( 'elementor/widgets/register', 'bce_register_widget' );
		add_action( 'elementor/elements/categories_registered', 'bce_register_widget_category' );
	}
} );
