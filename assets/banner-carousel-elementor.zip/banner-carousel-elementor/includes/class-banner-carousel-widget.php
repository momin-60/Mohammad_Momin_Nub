<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class Banner_Carousel_Widget extends Widget_Base {

	public function get_name() {
		return 'banner_image_carousel';
	}

	public function get_title() {
		return esc_html__( 'Banner Image Carousel', 'banner-carousel-elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() {
		return array( 'banner-carousel-category' );
	}

	public function get_keywords() {
		return array( 'carousel', 'slider', 'banner', 'image', 'gallery' );
	}

	public function get_script_depends() {
		return array( 'bce-script' );
	}

	public function get_style_depends() {
		return array( 'bce-style' );
	}

	protected function register_controls() {

		/* -----------------------------------------------------------
		 * CONTENT TAB -> SLIDES
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_slides',
			array(
				'label' => esc_html__( 'Slides', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Link control - works exactly like the normal WordPress post link
		// option (URL, open in new tab, add nofollow, custom attributes).
		$repeater->add_control(
			'link',
			array(
				'label'       => esc_html__( 'Link', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'banner-carousel-elementor' ),
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'show_label'  => true,
			)
		);

		$repeater->add_control(
			'title_text',
			array(
				'label'       => esc_html__( 'Title (optional)', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Slide title / alt text', 'banner-carousel-elementor' ),
				'default'     => '',
			)
		);

		$this->add_control(
			'slides',
			array(
				'label'       => esc_html__( 'Carousel Images', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'title_text' => esc_html__( 'Slide #1', 'banner-carousel-elementor' ),
					),
					array(
						'title_text' => esc_html__( 'Slide #2', 'banner-carousel-elementor' ),
					),
				),
				'title_field' => '{{{ title_text || "Slide" }}}',
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * CONTENT TAB -> SETTINGS (autoplay, dots, arrows...)
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_settings',
			array(
				'label' => esc_html__( 'Carousel Settings', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Autoplay', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'autoplay_speed',
			array(
				'label'     => esc_html__( 'Autoplay Speed (ms)', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 4000,
				'min'       => 1000,
				'step'      => 500,
				'condition' => array(
					'autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'transition_speed',
			array(
				'label'   => esc_html__( 'Transition Speed (ms)', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 600,
				'min'     => 100,
				'step'    => 100,
			)
		);

		$this->add_control(
			'pause_on_hover',
			array(
				'label'        => esc_html__( 'Pause on Hover', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_dots',
			array(
				'label'        => esc_html__( 'Show Dots', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_arrows',
			array(
				'label'        => esc_html__( 'Show Arrows', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * STYLE TAB -> IMAGE / CONTAINER
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_image',
			array(
				'label' => esc_html__( 'Image / Container', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'carousel_height',
			array(
				'label'      => esc_html__( 'Height', 'banner-carousel-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vh' ),
				'range'      => array(
					'px' => array(
						'min' => 100,
						'max' => 1200,
					),
					'vh' => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 700,
				),
				'selectors'  => array(
					'{{WRAPPER}} .bce-carousel' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'object_fit',
			array(
				'label'   => esc_html__( 'Image Fit', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => array(
					'cover'   => esc_html__( 'Cover', 'banner-carousel-elementor' ),
					'contain' => esc_html__( 'Contain', 'banner-carousel-elementor' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-slide img' => 'object-fit: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'image_bg_color',
			array(
				'label'     => esc_html__( 'Background Color (visible with Contain)', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'condition' => array(
					'object_fit' => 'contain',
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-slide' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'banner-carousel-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 100 ),
					'%'  => array( 'min' => 0, 'max' => 50 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bce-carousel' => 'border-radius: {{SIZE}}{{UNIT}}; overflow: hidden;',
				),
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * STYLE TAB -> DOTS
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_dots',
			array(
				'label'     => esc_html__( 'Dots', 'banner-carousel-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_dots' => 'yes',
				),
			)
		);

		$this->add_control(
			'dots_position',
			array(
				'label'     => esc_html__( 'Bottom Spacing', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 100 ),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 20,
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-dots' => 'bottom: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'dot_size',
			array(
				'label'     => esc_html__( 'Dot Size', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 4, 'max' => 30 ),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 10,
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'dot_color',
			array(
				'label'     => esc_html__( 'Dot Color', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(255,255,255,0.6)',
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'dot_active_color',
			array(
				'label'     => esc_html__( 'Active Dot Color', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button.active' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Build the opening <a> tag for a slide if a link is set, using
	 * Elementor's standard URL control (url / is_external / nofollow).
	 */
	private function render_link_attributes_key( $repeater_setting_key ) {
		$this->add_link_attributes( $repeater_setting_key, $this->get_settings_for_display( $repeater_setting_key ) );
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$slides   = $settings['slides'];

		if ( empty( $slides ) ) {
			return;
		}

		$widget_id      = $this->get_id();
		$show_dots      = 'yes' === $settings['show_dots'];
		$show_arrows    = 'yes' === $settings['show_arrows'];
		$autoplay       = 'yes' === $settings['autoplay'];
		$autoplay_speed = ! empty( $settings['autoplay_speed'] ) ? (int) $settings['autoplay_speed'] : 4000;
		$transition     = ! empty( $settings['transition_speed'] ) ? (int) $settings['transition_speed'] : 600;
		$pause_on_hover = 'yes' === $settings['pause_on_hover'];
		?>
		<div class="bce-carousel-wrapper">
			<div
				class="bce-carousel"
				id="bce-carousel-<?php echo esc_attr( $widget_id ); ?>"
				data-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>"
				data-autoplay-speed="<?php echo esc_attr( $autoplay_speed ); ?>"
				data-transition-speed="<?php echo esc_attr( $transition ); ?>"
				data-pause-on-hover="<?php echo $pause_on_hover ? 'true' : 'false'; ?>"
			>
				<div class="bce-track">
					<?php foreach ( $slides as $index => $slide ) :
						$image_url = ! empty( $slide['image']['url'] ) ? $slide['image']['url'] : '';
						$alt_text  = ! empty( $slide['title_text'] ) ? $slide['title_text'] : '';
						$has_link  = ! empty( $slide['link']['url'] );
						$link_key  = 'link_' . $index;
						?>
						<div class="bce-slide">
							<?php if ( $has_link ) :
								$this->add_link_attributes( $link_key, $slide['link'] );
								?>
								<a <?php echo $this->get_render_attribute_string( $link_key ); ?>>
									<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
								</a>
							<?php else : ?>
								<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<?php if ( $show_arrows && count( $slides ) > 1 ) : ?>
					<button type="button" class="bce-arrow bce-arrow-prev" aria-label="<?php esc_attr_e( 'Previous slide', 'banner-carousel-elementor' ); ?>">&#10094;</button>
					<button type="button" class="bce-arrow bce-arrow-next" aria-label="<?php esc_attr_e( 'Next slide', 'banner-carousel-elementor' ); ?>">&#10095;</button>
				<?php endif; ?>

				<?php if ( $show_dots && count( $slides ) > 1 ) : ?>
					<div class="bce-dots">
						<?php foreach ( $slides as $index => $slide ) : ?>
							<button
								type="button"
								class="<?php echo 0 === $index ? 'active' : ''; ?>"
								data-slide-index="<?php echo esc_attr( $index ); ?>"
								aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'banner-carousel-elementor' ), $index + 1 ) ); ?>"
							></button>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
