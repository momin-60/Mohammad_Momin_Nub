<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

class Banner_Carousel_Widget extends Widget_Base {

	public function get_name() {
		return 'banner_image_carousel';
	}

	public function get_title() {
		return esc_html__( 'Banner Image Carousel', 'banner-carousel-elementor' );
	}

	public function get_icon() {
		return 'eicon-slider-push';
	}

	public function get_categories() {
		return array( 'banner-carousel-category' );
	}

	public function get_keywords() {
		return array( 'carousel', 'slider', 'banner', 'image', 'gallery' );
	}

	public function get_script_depends() {
		return array( 'bce-script' );
	}

	public function get_style_depends() {
		return array( 'bce-style' );
	}

	protected function register_controls() {

		/* -----------------------------------------------------------
		 * CONTENT TAB -> SLIDES
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_slides',
			array(
				'label' => esc_html__( 'Slides', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'slides_source',
			array(
				'label'   => esc_html__( 'Slides Source', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'post_type',
				'options' => array(
					'post_type' => esc_html__( 'Banner Slides (Post Type)', 'banner-carousel-elementor' ),
					'manual'    => esc_html__( 'Manual (Repeater below)', 'banner-carousel-elementor' ),
				),
			)
		);

		$this->add_control(
			'post_type_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Slide add / edit / delete korte WP-Admin menu-r "Banner Slides" e jan. Prottekta slide-e Featured Image (image), Link (URL box) ebong Page Attributes > Order diye slide-er order set kora jay.', 'banner-carousel-elementor' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
				'condition'       => array(
					'slides_source' => 'post_type',
				),
			)
		);

		$this->add_control(
			'posts_number',
			array(
				'label'     => esc_html__( 'Number of Slides (-1 = all)', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => -1,
				'condition' => array(
					'slides_source' => 'post_type',
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'image',
			array(
				'label'   => esc_html__( 'Image', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				),
			)
		);

		// Link control - works exactly like the normal WordPress post link
		// option (URL, open in new tab, add nofollow, custom attributes).
		$repeater->add_control(
			'link',
			array(
				'label'       => esc_html__( 'Link', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'banner-carousel-elementor' ),
				'default'     => array(
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				),
				'show_label'  => true,
			)
		);

		$repeater->add_control(
			'title_text',
			array(
				'label'       => esc_html__( 'Title (optional)', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Slide title / alt text', 'banner-carousel-elementor' ),
				'default'     => '',
			)
		);

		$this->add_control(
			'slides',
			array(
				'label'       => esc_html__( 'Carousel Images', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'title_text' => esc_html__( 'Slide #1', 'banner-carousel-elementor' ),
					),
					array(
						'title_text' => esc_html__( 'Slide #2', 'banner-carousel-elementor' ),
					),
				),
				'title_field' => '{{{ title_text || "Slide" }}}',
				'condition'   => array(
					'slides_source' => 'manual',
				),
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * CONTENT TAB -> SETTINGS (autoplay, dots, arrows...)
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_settings',
			array(
				'label' => esc_html__( 'Carousel Settings', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'autoplay',
			array(
				'label'        => esc_html__( 'Auto Slide', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'slide_direction',
			array(
				'label'     => esc_html__( 'Slide Direction', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'ltr',
				'options'   => array(
					'ltr' => esc_html__( 'Left to Right', 'banner-carousel-elementor' ),
					'rtl' => esc_html__( 'Right to Left', 'banner-carousel-elementor' ),
				),
				'condition' => array(
					'autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'autoplay_speed',
			array(
				'label'       => esc_html__( 'Slide Speed (ms)', 'banner-carousel-elementor' ),
				'description' => esc_html__( 'Koto millisecond por porer slide-e jabe (interval).', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 4000,
				'min'         => 500,
				'step'        => 100,
				'condition'   => array(
					'autoplay' => 'yes',
				),
			)
		);

		$this->add_control(
			'transition_speed',
			array(
				'label'       => esc_html__( 'Animation Speed (ms)', 'banner-carousel-elementor' ),
				'description' => esc_html__( 'Ek slide theke arek slide-e move howar animation koto druto hobe.', 'banner-carousel-elementor' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => 700,
				'min'         => 100,
				'max'         => 3000,
				'step'        => 50,
			)
		);

		$this->add_control(
			'pause_on_hover',
			array(
				'label'        => esc_html__( 'Pause on Hover', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_dots',
			array(
				'label'        => esc_html__( 'Show Dots', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'show_arrows',
			array(
				'label'        => esc_html__( 'Show Arrows', 'banner-carousel-elementor' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'banner-carousel-elementor' ),
				'label_off'    => esc_html__( 'No', 'banner-carousel-elementor' ),
				'return_value' => 'yes',
				'default'      => 'no',
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * STYLE TAB -> IMAGE / CONTAINER
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_image',
			array(
				'label' => esc_html__( 'Image / Container', 'banner-carousel-elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'carousel_height',
			array(
				'label'      => esc_html__( 'Height', 'banner-carousel-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'vh' ),
				'range'      => array(
					'px' => array(
						'min' => 100,
						'max' => 1200,
					),
					'vh' => array(
						'min' => 10,
						'max' => 100,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 700,
				),
				'selectors'  => array(
					'{{WRAPPER}} .bce-carousel' => 'height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'object_fit',
			array(
				'label'   => esc_html__( 'Image Fit', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => array(
					'cover'   => esc_html__( 'Cover', 'banner-carousel-elementor' ),
					'contain' => esc_html__( 'Contain', 'banner-carousel-elementor' ),
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-slide img' => 'object-fit: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'image_bg_color',
			array(
				'label'     => esc_html__( 'Background Color (visible with Contain)', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'condition' => array(
					'object_fit' => 'contain',
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-slide' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'banner-carousel-elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array( 'min' => 0, 'max' => 100 ),
					'%'  => array( 'min' => 0, 'max' => 50 ),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bce-carousel' => 'border-radius: {{SIZE}}{{UNIT}}; overflow: hidden;',
				),
			)
		);

		$this->end_controls_section();

		/* -----------------------------------------------------------
		 * STYLE TAB -> DOTS
		 * --------------------------------------------------------- */
		$this->start_controls_section(
			'section_style_dots',
			array(
				'label'     => esc_html__( 'Dots', 'banner-carousel-elementor' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'show_dots' => 'yes',
				),
			)
		);

		$this->add_control(
			'dots_h_align',
			array(
				'label'   => esc_html__( 'Horizontal Position', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'left'   => array(
						'title' => esc_html__( 'Left', 'banner-carousel-elementor' ),
						'icon'  => 'eicon-h-align-left',
					),
					'center' => array(
						'title' => esc_html__( 'Center', 'banner-carousel-elementor' ),
						'icon'  => 'eicon-h-align-center',
					),
					'right'  => array(
						'title' => esc_html__( 'Right', 'banner-carousel-elementor' ),
						'icon'  => 'eicon-h-align-right',
					),
				),
				'default' => 'center',
				'toggle'  => false,
			)
		);

		$this->add_control(
			'dots_h_offset',
			array(
				'label'     => esc_html__( 'Horizontal Offset', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 0, 'max' => 300 ),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 20,
				),
				'condition' => array(
					'dots_h_align!' => 'center',
				),
			)
		);

		$this->add_control(
			'dots_v_align',
			array(
				'label'   => esc_html__( 'Vertical Position', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => array(
					'top'    => array(
						'title' => esc_html__( 'Top', 'banner-carousel-elementor' ),
						'icon'  => 'eicon-v-align-top',
					),
					'bottom' => array(
						'title' => esc_html__( 'Bottom', 'banner-carousel-elementor' ),
						'icon'  => 'eicon-v-align-bottom',
					),
				),
				'default' => 'bottom',
				'toggle'  => false,
			)
		);

		$this->add_control(
			'dots_v_offset',
			array(
				'label'   => esc_html__( 'Vertical Offset', 'banner-carousel-elementor' ),
				'type'    => Controls_Manager::SLIDER,
				'range'   => array(
					'px' => array( 'min' => 0, 'max' => 300 ),
				),
				'default' => array(
					'unit' => 'px',
					'size' => 20,
				),
			)
		);

		$this->add_control(
			'dot_size',
			array(
				'label'     => esc_html__( 'Dot Size', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => array(
					'px' => array( 'min' => 4, 'max' => 30 ),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 10,
				),
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'dot_color',
			array(
				'label'     => esc_html__( 'Dot Color', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'rgba(0, 0, 0, 0.25)',
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'dot_active_color',
			array(
				'label'     => esc_html__( 'Active Dot Color', 'banner-carousel-elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000000',
				'selectors' => array(
					'{{WRAPPER}} .bce-dots button.active' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Build a normalized slide list regardless of source (manual repeater
	 * or the "Banner Slide" post type), so render() only has one shape
	 * to deal with: image_url / alt / link_url / link_new_tab / link_nofollow.
	 */
	private function get_normalized_slides( $settings ) {
		$slides = array();

		if ( 'post_type' === $settings['slides_source'] ) {
			if ( class_exists( 'Banner_Slide_CPT' ) ) {
				$number = isset( $settings['posts_number'] ) ? (int) $settings['posts_number'] : -1;
				$slides = Banner_Slide_CPT::get_slides( $number );
			}
		} elseif ( ! empty( $settings['slides'] ) ) {
			// Manual repeater source.
			foreach ( $settings['slides'] as $item ) {
				$slides[] = array(
					'image_url'     => ! empty( $item['image']['url'] ) ? $item['image']['url'] : '',
					'alt'           => ! empty( $item['title_text'] ) ? $item['title_text'] : '',
					'link_url'      => ! empty( $item['link']['url'] ) ? $item['link']['url'] : '',
					'link_new_tab'  => ! empty( $item['link']['is_external'] ),
					'link_nofollow' => ! empty( $item['link']['nofollow'] ),
				);
			}
		}

		// Drop any slide that has no image at all - an <img src=""> would
		// otherwise render as a blank/broken box that still takes up the
		// full 700px height, which looks like "nothing is showing".
		$slides = array_values( array_filter( $slides, function ( $slide ) {
			return ! empty( $slide['image_url'] );
		} ) );

		return $slides;
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$slides   = $this->get_normalized_slides( $settings );

		if ( empty( $slides ) ) {
			// In the Elementor editor, show a helpful message instead of
			// just rendering nothing, so it's obvious what to fix.
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				$source_hint = 'post_type' === $settings['slides_source']
					? esc_html__( 'WP-Admin > Banner Slides e giye kono slide-e Featured Image set kora hoyni, othoba kono "Banner Slide" post publish kora hoyni.', 'banner-carousel-elementor' )
					: esc_html__( 'Slides repeater-e kono image upload kora hoyni.', 'banner-carousel-elementor' );

				printf(
					'<div style="padding:20px;background:#fff3cd;border:1px solid #ffe69c;color:#664d03;border-radius:4px;">%1$s<br>%2$s</div>',
					esc_html__( 'Kono image pawa jayni, tai carousel dekhano hocche na.', 'banner-carousel-elementor' ),
					$source_hint
				);
			}
			return;
		}

		$widget_id      = $this->get_id();
		$show_dots      = 'yes' === $settings['show_dots'];
		$show_arrows    = 'yes' === $settings['show_arrows'];
		$autoplay       = 'yes' === $settings['autoplay'];
		$direction      = ! empty( $settings['slide_direction'] ) ? $settings['slide_direction'] : 'ltr';
		$autoplay_speed = ! empty( $settings['autoplay_speed'] ) ? (int) $settings['autoplay_speed'] : 4000;
		$transition     = ! empty( $settings['transition_speed'] ) ? (int) $settings['transition_speed'] : 700;
		$pause_on_hover = 'yes' === $settings['pause_on_hover'];

		// Build inline style for the dots wrapper so its position is
		// fully custom (left/center/right + top/bottom + offsets).
		$dots_style = '';
		if ( $show_dots ) {
			$h_align   = ! empty( $settings['dots_h_align'] ) ? $settings['dots_h_align'] : 'center';
			$v_align   = ! empty( $settings['dots_v_align'] ) ? $settings['dots_v_align'] : 'bottom';
			$h_offset  = isset( $settings['dots_h_offset']['size'] ) ? (float) $settings['dots_h_offset']['size'] : 20;
			$h_unit    = ! empty( $settings['dots_h_offset']['unit'] ) ? $settings['dots_h_offset']['unit'] : 'px';
			$v_offset  = isset( $settings['dots_v_offset']['size'] ) ? (float) $settings['dots_v_offset']['size'] : 20;
			$v_unit    = ! empty( $settings['dots_v_offset']['unit'] ) ? $settings['dots_v_offset']['unit'] : 'px';

			$dots_style .= 'position:absolute;';

			if ( 'left' === $h_align ) {
				$dots_style .= 'left:' . $h_offset . $h_unit . ';';
			} elseif ( 'right' === $h_align ) {
				$dots_style .= 'right:' . $h_offset . $h_unit . ';';
			} else { // center
				$dots_style .= 'left:50%;transform:translateX(-50%);';
			}

			if ( 'top' === $v_align ) {
				$dots_style .= 'top:' . $v_offset . $v_unit . ';';
			} else {
				$dots_style .= 'bottom:' . $v_offset . $v_unit . ';';
			}
		}
		?>
		<div class="bce-carousel-wrapper">
			<div
				class="bce-carousel"
				id="bce-carousel-<?php echo esc_attr( $widget_id ); ?>"
				data-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>"
				data-direction="<?php echo esc_attr( $direction ); ?>"
				data-autoplay-speed="<?php echo esc_attr( $autoplay_speed ); ?>"
				data-transition-speed="<?php echo esc_attr( $transition ); ?>"
				data-pause-on-hover="<?php echo $pause_on_hover ? 'true' : 'false'; ?>"
			>
				<div class="bce-track">
					<?php foreach ( $slides as $slide ) :
						$image_url = $slide['image_url'];
						$alt_text  = $slide['alt'];
						$has_link  = ! empty( $slide['link_url'] );
						?>
						<div class="bce-slide">
							<?php if ( $has_link ) : ?>
								<a
									href="<?php echo esc_url( $slide['link_url'] ); ?>"
									<?php echo ! empty( $slide['link_new_tab'] ) ? 'target="_blank"' : ''; ?>
									<?php
									$rel = array();
									if ( ! empty( $slide['link_nofollow'] ) ) {
										$rel[] = 'nofollow';
									}
									if ( ! empty( $slide['link_new_tab'] ) ) {
										$rel[] = 'noopener';
									}
									if ( ! empty( $rel ) ) {
										echo 'rel="' . esc_attr( implode( ' ', $rel ) ) . '"';
									}
									?>
								>
									<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
								</a>
							<?php else : ?>
								<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $alt_text ); ?>" />
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<?php if ( $show_arrows && count( $slides ) > 1 ) : ?>
					<button type="button" class="bce-arrow bce-arrow-prev" aria-label="<?php esc_attr_e( 'Previous slide', 'banner-carousel-elementor' ); ?>">&#10094;</button>
					<button type="button" class="bce-arrow bce-arrow-next" aria-label="<?php esc_attr_e( 'Next slide', 'banner-carousel-elementor' ); ?>">&#10095;</button>
				<?php endif; ?>

				<?php if ( $show_dots && count( $slides ) > 1 ) : ?>
					<div class="bce-dots" style="<?php echo esc_attr( $dots_style ); ?>">
						<?php foreach ( $slides as $index => $slide ) : ?>
							<button
								type="button"
								class="<?php echo 0 === $index ? 'active' : ''; ?>"
								data-slide-index="<?php echo esc_attr( $index ); ?>"
								aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'banner-carousel-elementor' ), $index + 1 ) ); ?>"
							></button>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
