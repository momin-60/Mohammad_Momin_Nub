(function () {
	'use strict';

	function initCarousel( carouselEl ) {

		// Avoid double init (e.g. Elementor editor re-render).
		if ( carouselEl.getAttribute( 'data-bce-initialized' ) === 'true' ) {
			return;
		}

		var track = carouselEl.querySelector( '.bce-track' );
		var originalSlides = Array.prototype.slice.call( carouselEl.querySelectorAll( '.bce-slide' ) );

		if ( ! track || originalSlides.length < 1 ) {
			return;
		}

		var dotsWrap = carouselEl.querySelector( '.bce-dots' );
		var dots     = dotsWrap ? Array.prototype.slice.call( dotsWrap.querySelectorAll( 'button' ) ) : [];
		var prevBtn  = carouselEl.querySelector( '.bce-arrow-prev' );
		var nextBtn  = carouselEl.querySelector( '.bce-arrow-next' );

		var autoplay       = carouselEl.getAttribute( 'data-autoplay' ) === 'true';
		var direction      = carouselEl.getAttribute( 'data-direction' ) === 'rtl' ? 'rtl' : 'ltr';
		var autoplaySpeed  = parseInt( carouselEl.getAttribute( 'data-autoplay-speed' ), 10 ) || 4000;
		var transitionTime = parseInt( carouselEl.getAttribute( 'data-transition-speed' ), 10 ) || 700;
		var pauseOnHover   = carouselEl.getAttribute( 'data-pause-on-hover' ) === 'true';

		var slideCount   = originalSlides.length;
		var loopEnabled  = slideCount > 1;

		// For a smooth infinite loop, clone the first slide to the end
		// and the last slide to the start. Real slides then live at
		// internal indices 1..slideCount, with 0 and slideCount+1 being
		// the clones.
		if ( loopEnabled ) {
			var firstClone = originalSlides[ 0 ].cloneNode( true );
			var lastClone  = originalSlides[ slideCount - 1 ].cloneNode( true );
			firstClone.setAttribute( 'aria-hidden', 'true' );
			lastClone.setAttribute( 'aria-hidden', 'true' );
			track.appendChild( firstClone );
			track.insertBefore( lastClone, track.firstChild );
		}

		var allSlides   = Array.prototype.slice.call( track.children );
		var current     = loopEnabled ? 1 : 0; // internal index
		var timer       = null;
		var isAnimating = false;

		function setActiveDot( realIndex ) {
			dots.forEach( function ( dot, i ) {
				dot.classList.toggle( 'active', i === realIndex );
			} );
		}

		function realIndexFromInternal( internalIndex ) {
			if ( ! loopEnabled ) {
				return internalIndex;
			}
			return ( internalIndex - 1 + slideCount ) % slideCount;
		}

		function moveTo( internalIndex, withTransition ) {
			track.style.transition = withTransition ? ( 'transform ' + transitionTime + 'ms ease-in-out' ) : 'none';
			track.style.transform  = 'translateX(' + ( -internalIndex * 100 ) + '%)';
			current = internalIndex;
			setActiveDot( realIndexFromInternal( current ) );
		}

		function goToReal( realIndex ) {
			if ( isAnimating ) {
				return;
			}
			var internalTarget = loopEnabled ? realIndex + 1 : realIndex;
			isAnimating = true;
			moveTo( internalTarget, true );
		}

		function next() {
			if ( isAnimating ) {
				return;
			}
			isAnimating = true;
			moveTo( current + 1, true );
		}

		function prev() {
			if ( isAnimating ) {
				return;
			}
			isAnimating = true;
			moveTo( current - 1, true );
		}

		// Handle the "jump" back to the real slide after sliding onto a clone.
		track.addEventListener( 'transitionend', function ( e ) {
			if ( e.target !== track ) {
				return;
			}
			isAnimating = false;

			if ( ! loopEnabled ) {
				return;
			}

			if ( current === allSlides.length - 1 ) {
				// We're on the cloned first slide -> jump to the real first slide.
				moveTo( 1, false );
			} else if ( current === 0 ) {
				// We're on the cloned last slide -> jump to the real last slide.
				moveTo( slideCount, false );
			}
		} );

		function startAutoplay() {
			if ( ! autoplay || slideCount < 2 ) {
				return;
			}
			stopAutoplay();
			timer = setInterval( function () {
				if ( direction === 'rtl' ) {
					prev();
				} else {
					next();
				}
			}, autoplaySpeed );
		}

		function stopAutoplay() {
			if ( timer ) {
				clearInterval( timer );
				timer = null;
			}
		}

		// Initial position (no transition on first paint).
		moveTo( current, false );
		// Force reflow so subsequent transform changes actually animate.
		void track.offsetWidth;

		// Dot clicks.
		dots.forEach( function ( dot, i ) {
			dot.addEventListener( 'click', function () {
				goToReal( i );
				startAutoplay();
			} );
		} );

		// Arrow clicks.
		if ( nextBtn ) {
			nextBtn.addEventListener( 'click', function () {
				next();
				startAutoplay();
			} );
		}
		if ( prevBtn ) {
			prevBtn.addEventListener( 'click', function () {
				prev();
				startAutoplay();
			} );
		}

		// Pause on hover.
		if ( pauseOnHover ) {
			carouselEl.addEventListener( 'mouseenter', stopAutoplay );
			carouselEl.addEventListener( 'mouseleave', startAutoplay );
		}

		// Basic touch swipe support.
		var touchStartX = 0;
		carouselEl.addEventListener( 'touchstart', function ( e ) {
			touchStartX = e.changedTouches[ 0 ].screenX;
		}, { passive: true } );

		carouselEl.addEventListener( 'touchend', function ( e ) {
			var touchEndX = e.changedTouches[ 0 ].screenX;
			var diff = touchEndX - touchStartX;
			if ( Math.abs( diff ) > 40 ) {
				if ( diff < 0 ) {
					next();
				} else {
					prev();
				}
				startAutoplay();
			}
		}, { passive: true } );

		carouselEl.setAttribute( 'data-bce-initialized', 'true' );

		startAutoplay();
	}

	function initAll() {
		var carousels = document.querySelectorAll( '.bce-carousel' );
		carousels.forEach( initCarousel );
	}

	// Normal front-end load.
	document.addEventListener( 'DOMContentLoaded', initAll );

	// Re-init inside the Elementor editor when the widget is rendered/updated.
	if ( window.elementorFrontend ) {
		window.addEventListener( 'elementor/frontend/init', function () {
			elementorFrontend.hooks.addAction( 'frontend/element_ready/banner_image_carousel.default', function ( $scope ) {
				var el = $scope[ 0 ] ? $scope[ 0 ].querySelector( '.bce-carousel' ) : null;
				if ( el ) {
					initCarousel( el );
				}
			} );
		} );
	}
})();
