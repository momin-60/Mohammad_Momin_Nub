<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the "Banner Slide" custom post type so slides can be managed
 * from wp-admin just like normal posts (title, featured image, order),
 * plus a meta box for the slide's click-through link.
 */
class Banner_Slide_CPT {

	const POST_TYPE = 'bce_slide';

	public static function register_post_type() {

		$labels = array(
			'name'               => esc_html__( 'Banner Slides', 'banner-carousel-elementor' ),
			'singular_name'      => esc_html__( 'Banner Slide', 'banner-carousel-elementor' ),
			'add_new'            => esc_html__( 'Add New Slide', 'banner-carousel-elementor' ),
			'add_new_item'       => esc_html__( 'Add New Banner Slide', 'banner-carousel-elementor' ),
			'edit_item'          => esc_html__( 'Edit Banner Slide', 'banner-carousel-elementor' ),
			'new_item'           => esc_html__( 'New Banner Slide', 'banner-carousel-elementor' ),
			'view_item'          => esc_html__( 'View Banner Slide', 'banner-carousel-elementor' ),
			'search_items'       => esc_html__( 'Search Banner Slides', 'banner-carousel-elementor' ),
			'not_found'          => esc_html__( 'No slides found', 'banner-carousel-elementor' ),
			'not_found_in_trash' => esc_html__( 'No slides found in Trash', 'banner-carousel-elementor' ),
			'menu_name'          => esc_html__( 'Banner Slides', 'banner-carousel-elementor' ),
		);

		$args = array(
			'labels'              => $labels,
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_admin_bar'   => false,
			'exclude_from_search' => true,
			'capability_type'     => 'post',
			'hierarchical'        => false,
			'supports'            => array( 'title', 'thumbnail', 'page-attributes' ),
			'menu_icon'           => 'dashicons-images-alt2',
			'menu_position'       => 58,
		);

		register_post_type( self::POST_TYPE, $args );
	}

	public static function add_meta_boxes() {
		add_meta_box(
			'bce_slide_link_box',
			esc_html__( 'Slide Link (image click destination)', 'banner-carousel-elementor' ),
			array( __CLASS__, 'render_meta_box' ),
			self::POST_TYPE,
			'normal',
			'high'
		);
	}

	public static function render_meta_box( $post ) {
		wp_nonce_field( 'bce_slide_save_meta', 'bce_slide_meta_nonce' );

		$url      = get_post_meta( $post->ID, '_bce_link_url', true );
		$new_tab  = get_post_meta( $post->ID, '_bce_link_new_tab', true );
		$nofollow = get_post_meta( $post->ID, '_bce_link_nofollow', true );
		?>
		<p>
			<label for="bce_link_url"><strong><?php esc_html_e( 'Link URL', 'banner-carousel-elementor' ); ?></strong></label><br />
			<input type="url" id="bce_link_url" name="bce_link_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://example.com" style="width:100%;" />
		</p>
		<p>
			<label>
				<input type="checkbox" name="bce_link_new_tab" value="1" <?php checked( $new_tab, '1' ); ?> />
				<?php esc_html_e( 'Open in new tab', 'banner-carousel-elementor' ); ?>
			</label>
		</p>
		<p>
			<label>
				<input type="checkbox" name="bce_link_nofollow" value="1" <?php checked( $nofollow, '1' ); ?> />
				<?php esc_html_e( 'Add nofollow', 'banner-carousel-elementor' ); ?>
			</label>
		</p>
		<p class="description">
			<?php esc_html_e( 'Featured Image = the slide image. "Order" (in Page Attributes box) controls the slide sequence in the carousel.', 'banner-carousel-elementor' ); ?>
		</p>
		<?php
	}

	public static function save_meta( $post_id ) {
		if ( ! isset( $_POST['bce_slide_meta_nonce'] ) || ! wp_verify_nonce( $_POST['bce_slide_meta_nonce'], 'bce_slide_save_meta' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$url = isset( $_POST['bce_link_url'] ) ? esc_url_raw( trim( $_POST['bce_link_url'] ) ) : '';
		update_post_meta( $post_id, '_bce_link_url', $url );

		update_post_meta( $post_id, '_bce_link_new_tab', isset( $_POST['bce_link_new_tab'] ) ? '1' : '' );
		update_post_meta( $post_id, '_bce_link_nofollow', isset( $_POST['bce_link_nofollow'] ) ? '1' : '' );
	}

	/**
	 * Fetch published slides as a normalized array ready for rendering.
	 *
	 * @param int $number  -1 for all.
	 * @return array
	 */
	public static function get_slides( $number = -1 ) {
		$query = new WP_Query( array(
			'post_type'              => self::POST_TYPE,
			'post_status'            => 'publish',
			'posts_per_page'         => $number,
			'orderby'                => 'menu_order title',
			'order'                  => 'ASC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => false,
		) );

		$slides = array();

		foreach ( $query->posts as $post ) {
			$image_url = get_the_post_thumbnail_url( $post->ID, 'full' );

			$slides[] = array(
				'image_url'     => $image_url ? $image_url : '',
				'alt'           => get_the_title( $post ),
				'link_url'      => get_post_meta( $post->ID, '_bce_link_url', true ),
				'link_new_tab'  => (bool) get_post_meta( $post->ID, '_bce_link_new_tab', true ),
				'link_nofollow' => (bool) get_post_meta( $post->ID, '_bce_link_nofollow', true ),
			);
		}

		wp_reset_postdata();

		return $slides;
	}
}
